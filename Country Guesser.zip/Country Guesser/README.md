A country guessing game created using HTML, CSS and javascript where the user has to guess a country in the least number of guesses getting a hint that gets more and more obvious each guess.
The country that has to be guessed updates daily.
